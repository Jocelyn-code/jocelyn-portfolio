const menuToggle = document.getElementById("menuToggle");
    const navLinks = document.getElementById("navLinks");
    const contactForm = document.getElementById("contactForm");
    const formNote = document.getElementById("formNote");
    const yearEl = document.getElementById("year");

    yearEl.textContent = new Date().getFullYear();

    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("open");
    });

    document.querySelectorAll(".nav-links a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
      });
    });

    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      formNote.textContent = "Thanks - your message was captured in the demo. Connect this form to Formspree, Netlify Forms, or EmailJS next.";
      formNote.style.color = "#4c6b57";
      contactForm.reset();
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    }, { threshold: 0.12 });

    document.querySelectorAll(".reveal").forEach((item) => observer.observe(item));