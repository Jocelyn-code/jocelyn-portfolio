# Jocelyn Portfolio

Open this folder in Visual Studio Code.

Files:
- index.html
- style.css
- script.js

How to preview:
1. Open index.html in VS Code.
2. Right click and choose "Open with Live Server" if you have the Live Server extension.
3. Or double click index.html to open it in your browser.
